package com.mytv.launcher

import android.app.Activity
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    data class App(val label: String, val pkg: String, val img: Drawable)

    private lateinit var dock: LinearLayout
    private lateinit var grid: GridView
    private var apps = listOf<App>()
    private val prefs by lazy { getSharedPreferences("launcher", MODE_PRIVATE) }

    // Favoritas por defecto (se cambian con pulsación larga en la lista de apps)
    private val defaults =
        "com.google.android.youtube.tv,com.spotify.tv.android,com.stremio.one,com.amazon.amazonvideo.livingroom"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        dock = findViewById(R.id.dock)
        grid = findViewById(R.id.grid)
        grid.setOnItemClickListener { _, _, i, _ -> launch(apps[i].pkg) }
        grid.setOnItemLongClickListener { _, _, i, _ -> toggleFav(apps[i].pkg); true }
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        buildDock()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        showGrid(false)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (grid.visibility == View.VISIBLE) showGrid(false)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun loadApps() {
        val pm = packageManager
        fun query(cat: String) = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)
        apps = (query(Intent.CATEGORY_LEANBACK_LAUNCHER) + query(Intent.CATEGORY_LAUNCHER))
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { App(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.activityInfo.loadBanner(pm) ?: it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }

        grid.adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(p: Int) = apps[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, parent: ViewGroup): View {
                val a = apps[p]
                val box = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                }
                box.addView(ImageView(this@MainActivity).apply {
                    setImageDrawable(a.img)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    layoutParams = LinearLayout.LayoutParams(dp(170), dp(96))
                })
                box.addView(TextView(this@MainActivity).apply {
                    text = a.label
                    setTextColor(0xFFFFFFFF.toInt())
                    textSize = 14f
                    gravity = Gravity.CENTER
                    maxLines = 1
                })
                return box
            }
        }
    }

    private fun favs() = prefs.getString("favs", defaults)!!.split(",").filter { it.isNotBlank() }

    private fun buildDock() {
        dock.removeAllViews()
        favs().mapNotNull { p -> apps.find { it.pkg == p } }.forEach { a ->
            dock.addView(tile(a.img, 0, 170) { launch(a.pkg) })
        }
        dock.addView(tile(getDrawable(R.drawable.ic_apps)!!, dp(28), 96) { showGrid(true) })
        dock.addView(tile(getDrawable(R.drawable.ic_settings)!!, dp(28), 96) {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })
        dock.getChildAt(0)?.requestFocus()
    }

    private fun tile(img: Drawable, pad: Int, w: Int, onClick: () -> Unit): View =
        ImageView(this).apply {
            setImageDrawable(img)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(pad, pad, pad, pad)
            background = getDrawable(R.drawable.tile_bg)
            isFocusable = true
            layoutParams = LinearLayout.LayoutParams(dp(w), dp(96)).apply {
                setMargins(dp(6), dp(6), dp(6), dp(6))
            }
            setOnClickListener { onClick() }
            setOnFocusChangeListener { v, f ->
                val s = if (f) 1.1f else 1f
                v.animate().scaleX(s).scaleY(s).setDuration(120).start()
            }
        }

    private fun showGrid(show: Boolean) {
        grid.visibility = if (show) View.VISIBLE else View.GONE
        if (show) grid.requestFocus() else dock.getChildAt(0)?.requestFocus()
    }

    private fun toggleFav(pkg: String) {
        val l = favs().toMutableList()
        if (!l.remove(pkg)) l.add(pkg)
        prefs.edit().putString("favs", l.joinToString(",")).apply()
        Toast.makeText(this, if (pkg in l) "Añadida al inicio" else "Quitada del inicio", Toast.LENGTH_SHORT).show()
        buildDock()
    }

    private fun launch(pkg: String) {
        val i = packageManager.getLeanbackLaunchIntentForPackage(pkg) ?: packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) startActivity(i)
    }
}
