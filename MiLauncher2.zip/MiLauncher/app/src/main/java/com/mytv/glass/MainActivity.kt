package com.mytv.glass

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.*

class MainActivity : Activity() {

    class App(val label: String, val pkg: String, val img: Drawable, val banner: Boolean) {
        var color = 0
    }

    private lateinit var wp: ImageView
    private lateinit var wp2: ImageView
    private lateinit var blur: ImageView
    private lateinit var tint: View
    private lateinit var home: View
    private lateinit var dock: LinearLayout
    private lateinit var topBar: LinearLayout
    private lateinit var appName: TextView
    private lateinit var grid: GridView

    private var apps = listOf<App>()
    private var skipFocus = true
    private var tintColor = 0
    private var tintAnim: ValueAnimator? = null
    private val tintDrawable = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0, 0))
    private val prefs by lazy { getSharedPreferences("glass", MODE_PRIVATE) }

    private val wallpapers = intArrayOf(
        R.drawable.wp1, R.drawable.wp2, R.drawable.wp3, R.drawable.wp4,
        R.drawable.wp5, R.drawable.wp6, R.drawable.wp7, R.drawable.wp8
    )
    private val defaults =
        "com.google.android.youtube.tv,com.spotify.tv.android,com.stremio.one,com.amazon.amazonvideo.livingroom"

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        wp = findViewById(R.id.wp)
        wp2 = findViewById(R.id.wp2)
        blur = findViewById(R.id.blur)
        tint = findViewById(R.id.tint)
        home = findViewById(R.id.home)
        dock = findViewById(R.id.dock)
        topBar = findViewById(R.id.topBar)
        appName = findViewById(R.id.appName)
        grid = findViewById(R.id.grid)
        tint.background = tintDrawable

        // Reloj con degradado translúcido
        findViewById<TextView>(R.id.clock).addOnLayoutChangeListener { v, l, t, r, bt, ol, ot, orr, ob ->
            (v as TextView).paint.shader = LinearGradient(
                0f, 0f, 0f, (bt - t).toFloat(),
                intArrayOf(0xF2FFFFFF.toInt(), 0x80FFFFFF.toInt()), null, Shader.TileMode.CLAMP
            )
        }

        setWallpaper(prefs.getInt("wp", 0), false)

        topBar.addView(iconButton(R.drawable.ic_wallpaper) {
            val i = (prefs.getInt("wp", 0) + 1) % wallpapers.size
            prefs.edit().putInt("wp", i).apply()
            setWallpaper(i, true)
        })
        topBar.addView(iconButton(R.drawable.ic_apps) { showGrid(true) })
        topBar.addView(iconButton(R.drawable.ic_settings) {
            startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        })

        grid.setOnItemClickListener { _, _, i, _ -> launch(apps[i].pkg) }
        grid.setOnItemLongClickListener { _, _, i, _ -> toggleFav(apps[i].pkg); true }
        grid.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (grid.visibility == View.VISIBLE && pos in apps.indices) onAppFocus(apps[pos])
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
    }

    override fun onResume() {
        super.onResume()
        loadApps()
        blur.alpha = 0f
        tint.alpha = 0f
        showGrid(false)
        buildDock()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        showGrid(false)
        buildDock()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (grid.visibility == View.VISIBLE) { showGrid(false); buildDock() }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- Fondo ----------
    private fun setWallpaper(i: Int, animate: Boolean) {
        val bmp = BitmapFactory.decodeResource(resources, wallpapers[i])
        var s = bmp
        while (s.width > 64) s = Bitmap.createScaledBitmap(s, s.width / 2, s.height / 2, true)
        blur.setImageBitmap(s)
        if (!animate) { wp.setImageBitmap(bmp); return }
        wp2.setImageBitmap(bmp)
        wp2.alpha = 0f
        wp2.animate().alpha(1f).setDuration(700).withEndAction {
            wp.setImageBitmap(bmp)
            wp2.alpha = 0f
        }.start()
    }

    private fun setTint(c: Int) {
        tintColor = c
        val rgb = c and 0x00FFFFFF
        tintDrawable.setColors(intArrayOf(rgb or (0x30 shl 24), rgb or (0xCC shl 24)))
    }

    // Al enfocar una app: fondo desenfocado + degradado con el color de la app
    private fun onAppFocus(a: App?) {
        if (skipFocus) return
        if (a == null) {
            if (grid.visibility != View.VISIBLE) {
                blur.animate().alpha(0f).setDuration(400).start()
                tint.animate().alpha(0f).setDuration(400).start()
            }
            appName.text = ""
            return
        }
        appName.text = a.label
        blur.animate().alpha(1f).setDuration(450).start()
        tint.animate().alpha(1f).setDuration(450).start()
        if (tintColor == 0) setTint(a.color)
        tintAnim?.cancel()
        tintAnim = ValueAnimator.ofObject(ArgbEvaluator(), tintColor, a.color).apply {
            duration = 450
            addUpdateListener { setTint(it.animatedValue as Int) }
            start()
        }
    }

    // ---------- Apps ----------
    private fun loadApps() {
        val pm = packageManager
        fun query(cat: String) = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)
        apps = (query(Intent.CATEGORY_LEANBACK_LAUNCHER) + query(Intent.CATEGORY_LAUNCHER))
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map {
                val bn = it.activityInfo.loadBanner(pm)
                App(it.loadLabel(pm).toString(), it.activityInfo.packageName, bn ?: it.loadIcon(pm), bn != null)
            }
            .sortedBy { it.label.lowercase() }
        apps.forEach { it.color = dominant(it.img) }

        grid.adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(p: Int) = apps[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, parent: ViewGroup): View {
                val a = apps[p]
                val box = LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    setPadding(dp(8), dp(8), dp(8), dp(8))
                }
                box.addView(card(a, 132, 74, 4))
                box.addView(TextView(this@MainActivity).apply {
                    text = a.label
                    setTextColor(0xE6FFFFFF.toInt())
                    textSize = 13f
                    typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
                    gravity = Gravity.CENTER
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                })
                return box
            }
        }
    }

    private fun dominant(d: Drawable): Int {
        val s = 32
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        val dd = d.constantState?.newDrawable() ?: d
        dd.setBounds(0, 0, s, s)
        dd.draw(Canvas(bmp))
        val px = IntArray(s * s)
        bmp.getPixels(px, 0, s, 0, 0, s, s)
        val hsv = FloatArray(3)
        var r = 0.0; var g = 0.0; var bl = 0.0; var w = 0.0
        for (p in px) {
            if (Color.alpha(p) < 200) continue
            Color.colorToHSV(p, hsv)
            if (hsv[2] < 0.15f || (hsv[1] < 0.15f && hsv[2] > 0.85f)) continue
            val wt = hsv[1] * hsv[2] + 0.05
            r += Color.red(p) * wt; g += Color.green(p) * wt; bl += Color.blue(p) * wt; w += wt
        }
        if (w == 0.0) return 0xFF3A4A6B.toInt()
        Color.colorToHSV(Color.rgb((r / w).toInt(), (g / w).toInt(), (bl / w).toInt()), hsv)
        hsv[1] = hsv[1].coerceAtLeast(0.55f)
        hsv[2] = hsv[2].coerceIn(0.6f, 0.95f)
        return Color.HSVToColor(hsv)
    }

    private fun favs() = prefs.getString("favs", defaults)!!.split(",").filter { it.isNotBlank() }

    // ---------- Vistas ----------
    private fun card(a: App, w: Int, h: Int, margin: Int): ImageView = ImageView(this).apply {
        background = ColorDrawable(a.color)
        setImageDrawable(a.img.constantState?.newDrawable() ?: a.img)
        if (a.banner) {
            scaleType = ImageView.ScaleType.CENTER_CROP
        } else {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(w / 8), dp(h / 8), dp(w / 8), dp(h / 8))
        }
        clipToOutline = true
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) {
                o.setRoundRect(0, 0, v.width, v.height, dp(18).toFloat())
            }
        }
        layoutParams = LinearLayout.LayoutParams(dp(w), dp(h)).apply {
            setMargins(dp(margin), dp(margin), dp(margin), dp(margin))
        }
    }

    private fun tile(a: App): View = card(a, 168, 94, 10).apply {
        isFocusable = true
        foreground = getDrawable(R.drawable.card_ring)
        elevation = dp(4).toFloat()
        setOnClickListener { launch(a.pkg) }
        setOnFocusChangeListener { v, f -> pop(v, f, 1.14f); if (f) onAppFocus(a) }
    }

    private fun iconButton(res: Int, onClick: () -> Unit): View = ImageView(this).apply {
        setImageResource(res)
        setPadding(dp(13), dp(13), dp(13), dp(13))
        background = getDrawable(R.drawable.btn_bg)
        isFocusable = true
        layoutParams = LinearLayout.LayoutParams(dp(52), dp(52)).apply { setMargins(dp(8), 0, dp(8), 0) }
        setOnClickListener { onClick() }
        setOnFocusChangeListener { v, f -> pop(v, f, 1.15f); if (f) onAppFocus(null) }
    }

    private fun pop(v: View, f: Boolean, s: Float) {
        val k = if (f) s else 1f
        v.animate().scaleX(k).scaleY(k).translationZ(if (f) dp(12).toFloat() else 0f).setDuration(160).start()
    }

    private fun buildDock() {
        dock.removeAllViews()
        var list = favs().mapNotNull { p -> apps.find { it.pkg == p } }
        if (list.isEmpty()) list = apps.take(6)
        list.forEach { dock.addView(tile(it)) }
        appName.text = list.firstOrNull()?.label ?: ""
        skipFocus = true
        dock.getChildAt(0)?.requestFocus()
        dock.post { skipFocus = false }
    }

    private fun showGrid(show: Boolean) {
        if (show) {
            if (tintColor == 0 && apps.isNotEmpty()) setTint(apps[0].color)
            blur.animate().alpha(1f).setDuration(350).start()
            tint.animate().alpha(1f).setDuration(350).start()
            home.visibility = View.INVISIBLE
            grid.visibility = View.VISIBLE
            grid.requestFocus()
        } else {
            grid.visibility = View.GONE
            home.visibility = View.VISIBLE
            blur.animate().alpha(0f).setDuration(350).start()
            tint.animate().alpha(0f).setDuration(350).start()
        }
    }

    private fun toggleFav(pkg: String) {
        val l = favs().toMutableList()
        if (!l.remove(pkg)) l.add(pkg)
        prefs.edit().putString("favs", l.joinToString(",")).apply()
        Toast.makeText(this, if (pkg in l) "Añadida al inicio" else "Quitada del inicio", Toast.LENGTH_SHORT).show()
    }

    private fun launch(pkg: String) {
        val i = packageManager.getLeanbackLaunchIntentForPackage(pkg) ?: packageManager.getLaunchIntentForPackage(pkg)
        if (i != null) startActivity(i)
    }
}
